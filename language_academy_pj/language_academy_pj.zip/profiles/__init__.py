default_app_config = 'profiles.apps.ProfilesConfig'

# from .user import User


# __all__ = [
#     User,
# ]