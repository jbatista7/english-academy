$("#timepicker").timepicker({
  step: 60,
  timeFormat: "h:i A",
  scrollDefault: "now",
});
